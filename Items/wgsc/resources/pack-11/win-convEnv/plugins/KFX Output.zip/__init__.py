#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import, print_function)

import argparse
import cgi
import imp
import os
import platform
import re
import shutil
import sys
import traceback

from calibre.constants import (config_dir, get_version)
from calibre.customize.conversion import (OutputFormatPlugin, OptionRecommendation)
from calibre.ebooks.conversion import ConversionUserFeedBack
from calibre.ebooks.conversion.plugins.epub_output import EPUBOutput
from calibre.ebooks.oeb.base import OPF as OPFNS
from calibre.ebooks.metadata.opf2 import OPF
from calibre.utils.logging import Log

__license__   = "GPL v3"
__copyright__ = "2018, John Howell <jhowell@acm.org>"


PREPARED_FILE_SAVE_DIR = None
ASIN_RE = r"^B[0-9A-Z]{9}$"
AUTO_PAGES = "(auto)"           # fake name for automatic page number generation, instead of a lookup name


class KFXOutput(OutputFormatPlugin):
    name = "KFX Output"
    author = "jhowell"
    file_type = "kfx"
    version = (1, 19, 0)
    minimum_calibre_version = (2, 0, 0)                 # required for apsw with sqlite >= 3.8.2
    supported_platforms = ["windows", "osx"]

    options = {
        OptionRecommendation(name="force_cde_type_ebok", recommended_value=False,
            help="Always create a book (CDE Type=EBOK) instead of personal document (CDE Type=PDOC) even if an ASIN "
            "is not provided. Normally converted books are marked as personal documents unless the calibre book entry "
            "has a valid ASIN. Setting this option will cause all converted books to be marked as books. This results "
            "in different handling by Kindle apps and devices."),

        OptionRecommendation(name="show_kpr_logs", recommended_value=False,
            help="Show the full Kindle Previewer conversion logs in the job log. This shows all of the output produced "
            "by Kindle Previewer during conversion and may possibly help in debugging a conversion failure in cases where "
            "the error message produced does not provide enough information."),

        OptionRecommendation(name="approximate_pages", recommended_value=False,
            help="Create approximate page numbers if real page numbers are not present in the source file of the book. "
            "(The default value for this option will also be used the KFX Metadata Writer.)"),

        OptionRecommendation(name="number_of_pages_field", recommended_value=AUTO_PAGES,
            help=("Lookup name of the custom column holding the desired number of pages to produce when creating approximate "
            "page numbers for books. (A non-numeric or zero column value will cause the number of pages to be determined "
            "automatically based on the content of each book.) Leave this as '%s' to always determine page numbers "
            "automatically. (The default value for this option will also be used the KFX Metadata Writer.)") % AUTO_PAGES),
    }

    recommendations = EPUBOutput.recommendations

    def __init__(self, *args, **kwargs):
        self.cli = False
        OutputFormatPlugin.__init__(self, *args, **kwargs)

        self.epub_output_plugin = EPUBOutput(*args, **kwargs)

        self.resources = self.load_resources(["kfx.png", "plugin_widget.py"])
        self.load_kfx_icon()
        self.load_configuration_widget()
        self.init_embedded_plugins()


    def load_kfx_icon(self):
        # calibre does not include an icon for KFX format

        filename = os.path.join(config_dir, "resources", "images", "mimetypes", "kfx.png")
        if not os.path.isfile(filename):
            try:
                os.makedirs(os.path.dirname(filename))
            except:
                pass

            try:
                with open(filename, "wb") as f:
                    f.write(self.resources["kfx.png"])
            except:
                print("Failed to create KFX icon file")
                traceback.print_exc()


    def load_configuration_widget(self):
        # hack to work around OutputOptions.load_conversion_widgets() in calibre.gui2.preferences.conversion
        # not using gui_configuration_widget() to find configuration widgets for conversion plugins
        # it instead looks for a module named "calibre.gui2.convert.kfx_output" containing a PluginWidget

        try:
            from calibre_plugins.kfx_output.plugin_widget import PluginWidget
            self.PluginWidget = PluginWidget
        except:
            return      # not running GUI so no need to install this


        mod_name = "calibre.gui2.convert.kfx_output"        # expected name of module containing PluginWidget
        mod_src = self.resources["plugin_widget.py"]

        try:
            mod = imp.new_module(mod_name)
            exec mod_src in mod.__dict__        # compile source
            sys.modules[mod_name] = mod         # prevent any future import attempt

        except:
            print("Failed to create module %s" % mod_name)
            traceback.print_exc()


    def gui_configuration_widget(self, parent, get_option_by_name, get_option_help, db, book_id=None):
        from calibre_plugins.kfx_output.plugin_widget import PluginWidget
        return PluginWidget(parent, get_option_by_name, get_option_help, db, book_id)


    def convert(self, oeb_book, output, input_plugin, opts, log):
        self.report_version(log)

        #for mivals in oeb_book.metadata.items.values():
        #    for mival in mivals:
        #        log.info("metadata: %s" % repr(mival))

        try:
            book_name = unicode(oeb_book.metadata.title[0])
        except:
            book_name = ""

        asin = None
        for idre in ["^mobi-asin$", "^amazon.*$", "^asin$"]:
            for ident in oeb_book.metadata["identifier"]:
                idtype = ident.get(OPFNS("scheme"), "").lower()
                if re.match(idre, idtype) and re.match(ASIN_RE, ident.value):
                    asin = ident.value
                    log.info("Found ASIN metadata %s: %s" % (idtype, asin))
                    break

            if asin:
                break

        #with open(opts.read_metadata_from_opf, "rb") as opff:
        #    log.info("opf: %s" % opff.read())

        if opts.approximate_pages:
            page_count = 0
            if opts.number_of_pages_field and opts.number_of_pages_field != AUTO_PAGES and opts.read_metadata_from_opf:
                # This OPF contains custom column metadata not present in the oeb_book OPF
                opf = OPF(opts.read_metadata_from_opf, populate_spine=False, try_to_guess_cover=False, read_toc=False)
                mi = opf.to_book_metadata()
                page_count_str = mi.get(opts.number_of_pages_field, None)

                if page_count_str is not None:
                    try:
                        page_count = int(page_count_str)
                    except:
                        pass

                    log.info("Page count value from field %s: %d ('%s')" % (opts.number_of_pages_field, page_count, page_count_str))
                else:
                    log.warning("Book has no page count field %s" % opts.number_of_pages_field)
        else:
            page_count = -1

        #log.info("oeb_book contains %d pages" % len(oeb_book.pages.pages))
        #log.info("options: %s" % unicode(opts.__dict__))

        # set default values for options expected by the EPUB Output plugin
        for optrec in EPUBOutput.options:
            setattr(opts, optrec.option.name, optrec.recommended_value)

        # override currently known EPUB Output plugin options
        opts.extract_to = None
        opts.dont_split_on_page_breaks = False
        opts.flow_size = 0
        opts.no_default_epub_cover = False
        opts.no_svg_cover = False
        opts.preserve_cover_aspect_ratio = True
        opts.epub_flatten = False
        opts.epub_inline_toc = False
        opts.epub_toc_at_end = False
        opts.toc_title = None

        epub_filename = self.temporary_file(".epub").name
        self.epub_output_plugin.convert(oeb_book, epub_filename, input_plugin, opts, log)  # convert input format to EPUB
        log.info("Successfully converted input format to EPUB")

        if PREPARED_FILE_SAVE_DIR:
            if not os.path.exists(PREPARED_FILE_SAVE_DIR):
                os.makedirs(PREPARED_FILE_SAVE_DIR)

            prepared_file_path = os.path.join(PREPARED_FILE_SAVE_DIR, os.path.basename(epub_filename))
            shutil.copyfile(epub_filename, prepared_file_path)
            log.warning("Saved conversion input file: %s" % prepared_file_path)

        self.convert_using_previewer(JobLog(log), book_name, epub_filename, asin, opts.force_cde_type_ebok,
                    page_count, opts.show_kpr_logs, False, output)


    def cli_main(self, argv):
        self.cli = True
        log = JobLog(Log())
        self.report_version(log)
        log.info("")

        allowed_exts = [".last", ".epub", ".opf", ".mobi", ".doc", ".docx", ".kpf", ".kfx-zip"]
        ext_choices = ", ".join(allowed_exts[:-1] + ["or " + allowed_exts[-1]])

        parser = argparse.ArgumentParser(prog='calibre-debug -r "KFX Output" --', description="Convert e-book to KFX format")
        parser.add_argument("-a", "--asin", action="store", help="Optional ASIN to assign to the book")
        parser.add_argument("-b", "--book", action="store_true", help="Force create book (EBOK) instead of personal document (PDOC)")
        parser.add_argument("-c", "--clean", action="store_true", help="Save the input file cleaned for conversion to KFX")
        parser.add_argument("-p", "--pages", action="store", type=int, default=-1,
                help="Create n approximate page numbers if missing from input file (0 for auto)")
        parser.add_argument("infile", help="Pathname of the %s file to be converted to .kfx" % ext_choices)
        parser.add_argument("outfile", nargs="?", help="Optional pathname of the resulting .kfx file")
        args = parser.parse_args(argv[1:])     # argv provided by calibre is unicode

        input = book_name = args.infile
        intype = os.path.splitext(input)[1]

        if (intype != ".last") and (not os.path.isfile(input)):
            raise Exception("Input file does not exist: %s" % input)

        if args.outfile:
            output = args.outfile
        else:
            output = os.path.join(os.path.dirname(input), os.path.splitext(os.path.basename(input))[0] + ".kfx")

        if not output.endswith(".kfx"):
            raise Exception("Output file must have .kfx extension")

        if intype in [".kpf", ".kfx-zip"]:
            self.convert_from_kpf_or_zip(log, book_name, input, args.asin, args.book, args.pages, intype == ".kfx-zip", output)
        elif intype in allowed_exts:
            self.convert_using_previewer(log, book_name, input, args.asin, args.book, args.pages, False, args.clean, output)
        else:
            raise Exception("Input file must be %s" % ext_choices)


    def report_version(self, log):
        log.info("Software versions: %s %s, calibre %s, %s" % (self.name, ".".join([unicode(v) for v in self.version]),
                get_version(), platform.platform()))
        log.info("KFX Output plugin help is available at http://www.mobileread.com/forums/showthread.php?t=272407")


    def convert_using_previewer(self, log, book_name, input_filename, asin, force_cde_type_ebok, approximate_pages,
                include_logs, clean, output):
        from calibre_plugins.kfx_output.kfxlib import (file_write_binary, YJ_Book)

        log.info("Converting %s" % input_filename)
        cleaned_filename = None

        if clean:
            result = YJ_Book(input_filename, log).convert_to_kpf(prep_only=True)
            if result.cleaned_epub_data:
                cleaned_filename = os.path.splitext(output)[0] + "_cleaned.epub"
                file_write_binary(cleaned_filename, result.cleaned_epub_data)
                log.info("Saved cleaned conversion input file to %s" % cleaned_filename)

        result = YJ_Book(cleaned_filename or input_filename, log).convert_to_kpf(tail_logs=not include_logs,
                        do_prep=cleaned_filename is None)


        if not result.kpf_data:
            log.info("\n****************** Conversion Failure Reason *****************")
            log.info(result.error_msg)
            log.info("**************************************************************")

        if result.guidance:
            log.info("\n************ Kindle Previewer Conversion Guidance ************")
            print(result.guidance)
            log.info("**************************************************************")

        if result.logs and (include_logs or not result.kpf_data):
            log.info("\n************** Kindle Previewer Conversion Logs **************")
            print(result.logs)
            log.info("*************************************************************")


        if not result.kpf_data:
            self.report_failure("Conversion error", result.error_msg, book_name)

        kpf_filename = self.temporary_file(".kpf").name
        file_write_binary(kpf_filename, result.kpf_data)

        input_format = os.path.splitext(input_filename)[1][1:].upper()

        log.info("Successfully converted %s to KPF" % ("last Kindle Previewer GUI result" if input_format == "LAST" else input_format))

        self.convert_from_kpf_or_zip(log, book_name, kpf_filename, asin, force_cde_type_ebok, approximate_pages, False, output)


    def convert_from_kpf_or_zip(self, log, book_name, input, asin, force_cde_type_ebok, approximate_pages, from_zip, output):
        from calibre.ebooks.metadata import author_to_author_sort
        from calibre_plugins.kfx_output.kfxlib import (file_write_binary, YJ_Book, YJ_Metadata)

        # would be better to use db.author_sort_from_authors instead of author_to_author_sort since that uses the author table
        # controlled by user, but the db is not available when conversion is performed.

        log.info("Converting %s" % input)

        if from_zip:
            md = None       # keep existing metadata
        else:
            md = YJ_Metadata(author_sort_fn=author_to_author_sort, replace_existing_authors_with_sort=True)
            md.asin = asin or True      # generate random if none set
            md.cde_content_type = "EBOK" if (asin and len(asin) == 10) or force_cde_type_ebok else "PDOC"

        kfx_data = YJ_Book(input, log, metadata=md, approximate_pages=approximate_pages).convert_to_single_kfx()    # repackage KPF as KFX

        if log.errors and not self.cli:
            self.report_failure("KFX creation error", "\n".join(log.errors), book_name)

        file_write_binary(output, kfx_data)
        log.info("Successfully converted to KFX")


    def report_failure(self, cat, msg, book_name):
        if self.cli:
            raise Exception(cat + ": " + msg)
        else:
            bn = "<b>Cannot convert " + clean_msg(book_name) + "</b><br><br>" if book_name else ""
            raise ConversionUserFeedBack("KFX conversion failed", bn + "<b>" + cat + ":</b> " + clean_msg(msg), level="error")


    def init_embedded_plugins(self):
        from calibre.customize.ui import (_initialized_plugins, reread_metadata_plugins)
        from calibre_plugins.kfx_output.metadata_writer import KFXMetadataWriter

        for pi in _initialized_plugins:
            if isinstance(pi, KFXMetadataWriter):
                break       # already initialized
        else:
            KFXMetadataWriter.version = self.version
            metadata_writer_plugin = KFXMetadataWriter(self.plugin_path)
            _initialized_plugins.append(metadata_writer_plugin)
            metadata_writer_plugin.initialize()
            reread_metadata_plugins()


def clean_msg(msg):
    # remove chars that cause problems for ConversionUserFeedBack
    return cgi.escape(msg).replace("%","%%").replace("{","(").replace("}",")")



class JobLog(object):
    '''
    Logger that also collects errors and warnings for presentation in a job summary.
    '''

    def __init__(self, logger):
        self.logger = logger
        self.errors = []
        self.warnings = []

    def debug(self, msg):
        self.logger.debug(msg)

    def info(self, msg):
        self.logger.info(msg)

    def warn(self, msg):
        self.warnings.append(msg)
        self.logger.warn("WARNING: %s" % msg)

    def warning(self, desc):
        self.warn(desc)

    def error(self, msg):
        self.errors.append(msg)
        self.logger.error("ERROR: %s" % msg)

    def exception(self, msg):
        self.errors.append("EXCEPTION: %s" % msg)
        self.logger.exception("EXCEPTION: %s" % msg)
