make to compile

paper2.pdf is locally compiled paper (as backup)

main.pdf is the pdf you just created from main.tex