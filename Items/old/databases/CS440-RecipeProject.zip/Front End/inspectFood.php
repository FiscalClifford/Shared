<?php
   
session_start();
        
//AIzaSyA-brEl9jsVlfRxojj8O56_6qR3k3oWRlc

  $file = file_get_contents("db-password.txt") or die("unable to open file");

  $DB_HOST = 'classmysql';
  $DB_USER = 'cs440_berksn';
  $DB_PASS = $file;
  $DB_NAME = 'cs440_berksn';

  $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS,  $DB_NAME);
  if ( mysqli_connect_errno() ) {

          die ('Failed to connect to MySQL: ' . mysqli_connect_error());
  }

  
    $item = $_GET['val'];
    $getRecipe = mysqli_query($conn, "SELECT * FROM Recipe WHERE name LIKE '%$item%' LIMIT 1") or die(mysql_error());
    $recipe  = mysqli_fetch_assoc($getRecipe);
  
?>


<html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>title</title>
<style>

.content{
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}

.bodyintro{
    padding:20px;
    margin-top:30px;
    font-size: 28px;
    background-color:lightgray;
    text-align: center;
}

.bodyingredients{
    padding:20px;
    margin-top:30px;
    font-size: 15px;
    background-color:lightgray;
    text-align: left;
    font-family:'Courier New', Courier, monospace;
}

.bodyinstructions{
    padding:20px;
    margin-top:30px;
    font-size: 16px;
    background-color:grey;
    text-align: left;
    font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
    font-weight: bold;
    line-height:5%
}

.dropbtn {
  background-color: orange;
  color: black;
  margin: 0;
  padding: 0;
  font-size: 16px;
  border: solid;
  cursor: pointer;
  position: fixed;
  top: 0;
  width: 100%;
  font-size: 50px;
}

.goButton {
  background-color: orange;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: solid;
  cursor: pointer;
  width: 85%;
}

.closeButton {
  background-color: red;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: solid;
  cursor: pointer;
  width: 10%;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: darkgoldenrod;
}

#userInput {
  
  background-image: url('https://image.flaticon.com/icons/png/512/640/640714.png');
  background-size: contain;
  background-repeat: no-repeat;
  font-size: 16px;
  padding: 14px 20px 12px 45px;
  border: none;
  border-bottom: 1px solid #ddd;
  width: 100%;
}

img{
    width:800px;
    height:500px;
}

#userInput:focus {outline: 3px solid #ddd;}

.dropdown {
  position: fixed;
  display: inline-block;
  padding-top: 33px;
}

.dropdown-content {
  display: none;
  width: 100%;
  position: fixed;
  background-color: #f6f6f6;
  min-width: 230px;
  overflow: auto;
  border: 1px solid #ddd;
  z-index: 1;
}


.dropdown-content checkbox {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}



 /* Table */
 .data-table {
  border-collapse: collapse;
  font-size: 14px;
  min-width: 537px;
}

.data-table th, 
.data-table td {
  border: 1px solid #e1edff;
  padding: 10px 17px;
  width: 100%
}
.data-table caption {
        margin: 7px;
}

/* Table Header */
.data-table thead th {
  background-color: #508abb;
  color: #FFFFFF;
  border-color: #6ea1cc !important;
  text-transform: uppercase;
  font-weight: bold;
}

/* Table Body */
.data-table tbody td {
  color: #353535;
}
.data-table tbody td:first-child,
.data-table tbody td:nth-child(4),
.data-table tbody td:last-child {
  text-align: right;
}

.data-table tbody tr:nth-child(odd) td {
  background-color: #f4fbff;
}
.data-table tbody tr:hover td {
  background-color: #ffffa2;
  border-color: #ffff0f;
}

.show {display: block;}
</style>
</head>
<body>

<div class="dropdown">
  <button onclick="dropdownFunction()" class="dropbtn">Search</button>
  <div id="dropdown-section" class="dropdown-content">
      <input type="text" placeholder="Search..." id="userInput" onkeypress="enterlistener(event)"><br>
      <button onclick="searchFunction()" class="goButton">GO!</button>
      <button onclick="dropdownFunction()" class="closeButton">X</button>
  </div>
</div>

<div class="bodyintro" onclick="hidesearchbar()">

    <?php
      
      echo '<h2>'.$recipe['name'].'</h2>';
      echo '<p>Category: '.$recipe['category'].'</p>';
    ?>
  

</div>

<div id="content" class="content"></div>
    
    
  <script>
  var searchitem = "<?php echo $recipe['name']; ?>"
  var url = "https://www.googleapis.com/customsearch/v1?key=AIzaSyA-brEl9jsVlfRxojj8O56_6qR3k3oWRlc&cx=005124428384360536924:rstfldysumw&q="+searchitem+"&searchType=image&safe=high";

  $(function () {
  var jqxhr = $.getJSON(url, function () {
    console.log("success");
  }).done(function (data) {

    for (var i = 0; i < 1; i++) {
      var item = data.items[i];    									
      document.getElementById("content").innerHTML += "<br><div class='c'>" 
          + "<div class='b'><img src="+ item.link +" height=200px width=200px /></div></div>";
    }           

  }).fail(function (data) {
    console.log("error");
  });
}); 

</script>




<div class="bodyinstructions" onclick="hidesearchbar()">
   <h2>Instructions:</h2><br>
   <?php
    $newdesc = str_replace('.','</p></br><p>',$recipe['directions']);
    echo '<p>'.$newdesc.'</p>';

   ?>

</div>


<div class="bodyingredients" onclick="hidesearchbar()">
  
  <h2> Shopping Helper:</h2>
  <table class = "data-table">
    <?php
      
      echo '<thead><tr><th>Ingredient</th><th>Amount</th><th>cost</th></tr></thead>';
      echo '<tbody>';
      $step1 = $recipe['id'];
      $step2 = mysqli_query($conn, "SELECT iid FROM RtoI WHERE rid='$step1'") or die(mysql_error());
      //$ing = mysqli_fetch_assoc($step2);
      //echo '<p>'.$ing['iid'].'</p>';

          while ($ing = mysqli_fetch_assoc($step2)){
            //echo '<p>'.$ing['iid'].'</p></br>';
            $temp = $ing['iid'];
            $step3 = mysqli_query($conn, "SELECT * FROM Ingredient WHERE id='$temp'") or die(mysql_error());
            $ingred = mysqli_fetch_assoc($step3);
            //echo '<p>'.$ingred['id'].' '.$ingred['portion'].'</p></br>';
            $fid = $ingred['fid'];

            $step5 = mysqli_query($conn, "SELECT * FROM Food WHERE id='$fid'") or die(mysql_error());
            $food = mysqli_fetch_assoc($step5);

            
            echo '<tr><td>'.$food['name'].'</td><td>'.$ingred['portion'].'</td><td>'.$food['cost'].'</td></tr>';
          }

      echo '</tbody';
      ?>
  </table>
</div>



<script>
    function dropdownFunction() {
  document.getElementById("dropdown-section").classList.toggle("show");
  
}

    function hidesearchbar() {
        var container = $("dropdown-section");
        container.hide();
    }


function searchFunction() {
    var searchItem = document.getElementById("userInput").value;
    var toSend = "inspectFood.php?val=" + searchItem;
    window.location.href = toSend;
}
function enterlistener(e){
  var keycode = (e.keyCode ? e.keyCode : e.which);
  if (keycode == '13'){
    searchFunction();
  }
}
</script>

</body>
</html>
