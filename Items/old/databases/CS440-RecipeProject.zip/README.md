# CS440-RecipeProject
Recipe Project for DBMS

phpMyAdmin information

host: tools.engr.oregonstate.edu
user: cs440_berksn
database: cs440_berksn

URL: http://web.engr.oregonstate.edu/~gilesbr/recipe/index.html

Files:
- dataUpload.py: uses the data found in food_names.txt to push information using SQL queries to our phpMyAdmin database and populate our tables

- food_names.txt: holds the information collected from our dataset (found in USDA database)

- Front End/..: all of our front end code used to create our webpage and display our database information in a user friendly fashion 
