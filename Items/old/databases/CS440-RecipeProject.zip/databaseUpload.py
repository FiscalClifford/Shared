import random
import mysql.connector

mydb = mysql.connector.connect(
    host="",
    user="",
    passwd="",
    database=""
)

cursor = mydb.cursor()
moods = ["happy", "sad", "angry", "surprised", "dissapointed", "failed your midterm", "primitive", "edible", "sneak to the dog"]
size = [" cup(s)", " tbsp(s)"," tsp(s)", " oz"]
names = ["Casserole", "Bake", "Linguine", "Crisp", "Bowl", "Smoothie", "Parfait", "Sandwhich", "Tostada", "Taco", "Loaf", "Pasta", "Wrap", "Crunch", "Melt", "Fritters", "Brulee", "Panini", "Mix", "Souffle", "Cake", "Brownie", "Omelette", "Sear", "Shake"]
actions = ["diced", "minced", "chopped", "finely chopped", "julienned", "boiled", "steamed", "raw", "sauteed", "fried", "baked", "broiled", "toasted", "cubed", "rinsed", "peeled", "mashed", "blended", "whipped"]
array = []


def populateFood():
    with open("food_names.txt", "r") as ins:
        for line in ins:
            line = line.rstrip("\n\r")
            if(line not in array and len(line) < 40):
                array.append(line)
                name = line
                cost = random.randint(1, 15)
                nutrition = random.randint(1, 5)
                sql = "INSERT INTO Food (name, cost, nutrition) VALUES (%s, %s, %s)"
                val = (name, cost, nutrition)
                cursor.execute(sql, val)
                mydb.commit()

def populateIngredient():
    sql = "SELECT id FROM Food LIMIT 1"
    cursor.execute(sql)
    result = cursor.fetchone()
    for x in range(0, len(array)):
        
        portion = random.randint(1,10) 
        fid = x + result[0]
        portionStr = str(portion) + (size[random.randint(0,3)])
        sql = "INSERT INTO Ingredient (fid, portion) VALUES (%s, %s)"
        val = (fid, portionStr)
        cursor.execute(sql, val)
        mydb.commit()

def populateRecipe():
    limit = random.randint(3, 10)
    sql = "SELECT name, portion, Ingredient.id FROM Ingredient INNER JOIN Food on Food.id = Ingredient.fid ORDER BY RAND() LIMIT " + str(limit)
    val = (limit)
    cursor.execute(sql, val)
    result = cursor.fetchall()
    name = str(result[0][0]) + " " + names[random.randint(0, len(names) - 1)].upper()
    category = moods[random.randint(0, len(moods) - 1)].upper()
    directions = ""
    for res in result:
        directions += str(res[1]) + " " + str(res[0]) + "........." + actions[random.randint(0, len(actions) - 1)].upper() + ".\n"
    directions += "\nCombine all ingredients and serve as desired"
    
    sql = "INSERT INTO Recipe (name, directions, category) VALUES(%s, %s, %s)"
    val = (name, directions, category)
    cursor.execute(sql, val)
    mydb.commit()

    recipeid = cursor.lastrowid
    for res in result:
        sql = "INSERT INTO RtoI (rid, iid) VALUES(%s, %s)"
        val = (recipeid, int(res[2]))
        cursor.execute(sql, val)
        mydb.commit()
 
populateFood()          # read from food_names.txt to populate food table
populateIngredient()    # take a food and a portion to create an ingredient
populateIngredient()    # create another set of ingredients
for i in range(1000):   # generate 1000 recipes using random ingredients
    populateRecipe()    
